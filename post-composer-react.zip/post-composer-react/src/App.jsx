import { useState } from "react";

const LIMITS = {
  Twitter: 280,
  LinkedIn: 3000,
};

export default function App() {
  const [platform, setPlatform] = useState("Twitter");
  const [post, setPost] = useState("");

  const limit = LIMITS[platform];
  const isOverLimit = post.length > limit;

  function handlePlatformChange(event) {
    setPlatform(event.target.value);
  }

  function handlePostChange(event) {
    setPost(event.target.value);
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (!post.trim()) {
      return;
    }
    if (isOverLimit) {
      return;
    }
    window.alert(`Your ${platform} post is ready to publish!`);
  }

  return (
    <main className="page">
      <section className="composer">
        <div className="eyebrow">SOCIAL MEDIA TOOL</div>
        <h1>Post Composer</h1>
        <p className="subtitle">
          Write once, check your character count, and get your post ready.
        </p>

        <form onSubmit={handleSubmit}>
          <label htmlFor="platform">Choose a platform</label>
          <select id="platform" value={platform} onChange={handlePlatformChange}>
            <option value="Twitter">Twitter / X</option>
            <option value="LinkedIn">LinkedIn</option>
          </select>

          <label htmlFor="post">Your post</label>
          <textarea
            id="post"
            value={post}
            onChange={handlePostChange}
            placeholder={`What would you like to share on ${platform}?`}
            rows={8}
            aria-describedby="character-count limit-message"
          />

          <div className={`counter ${isOverLimit ? "counter-error" : ""}`} id="character-count" aria-live="polite">
            <span>{post.length} / {limit} characters</span>
            <span>{limit - post.length >= 0 ? `${limit - post.length} remaining` : `${post.length - limit} over limit`}</span>
          </div>

          {isOverLimit && (
            <p className="error" id="limit-message" role="alert">
              Your post exceeds the {limit}-character limit for {platform}. Please shorten it by {post.length - limit} character(s).
            </p>
          )}

          <button type="submit" disabled={!post.trim() || isOverLimit}>
            Prepare post
          </button>
        </form>
        <p className="note">
          This demo checks character limits locally. It does not publish directly to either platform.
        </p>
      </section>
    </main>
  );
}
